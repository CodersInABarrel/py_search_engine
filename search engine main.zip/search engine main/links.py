import webbrowser
def pat():
    webbrowser.open('http://www.patreon.com')
def disc():
    webbrowser.open('https://discord.gg/7bngNUx')
